====================================
Single Cell RNA-Seq tools (scrtools)
====================================

scrtools is a tool for analyzing transcriptomes of millions of single cells. It is a command line tool, a python package and a base for Cloud-based analysis workflows.
