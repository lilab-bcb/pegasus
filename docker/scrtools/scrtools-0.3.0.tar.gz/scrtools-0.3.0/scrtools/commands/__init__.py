from .AggregateMatrix import AggregateMatrix as aggregate_matrix
from .Clustering import Clustering as cluster
from .SubClustering import SubClustering as subcluster
from .DeAnalysis import DeAnalysis as de_analysis
from .AnnotateCluster import AnnotateCluster as annotate_cluster
from .Plotting import Plotting as plot
from .iPlotting import iPlotting as iplot
